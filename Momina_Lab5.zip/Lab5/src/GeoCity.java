/* Momina Ramzan - 05259 - BESE - 4A */



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.mysql.jdbc.PreparedStatement;
 
public class GeoCity
{
    public static void main(String[] args) 
    {
        DBase db = new DBase();
        Connection conn = db.connect("jdbc:mysql://localhost:3306/lab05","root","");
       // db.importData(conn);
        db.searchData(conn);
        db.greatCircle(conn);
    }
 
}
 
class DBase
{
    public DBase()
    {
    }
 
    public Connection connect(String db_connect_str, String db_userid, String db_password)
    {
        Connection conn;
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
 
            conn = DriverManager.getConnection(db_connect_str, db_userid, db_password);
         
        }
        catch(Exception e)
        {
            e.printStackTrace();
            conn = null;
        }
 
        return conn;    
    }
     
    public void importData(Connection conn)
    {
        Statement stmt;
        String query;
 
        try
        {
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
 
            query = "LOAD DATA INFILE 'E:/Eclipse Workspace/Lab5/GeoLiteCity-Location.csv' INTO TABLE lab05.geocity FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n'(locId, country, city, region, postalCode,  longitude, latitude, metroCode , areaCode);";
 
                       
            stmt.executeUpdate(query);
                 
        }
        catch(Exception e)
        {
            e.printStackTrace();
            stmt = null;
        }
    }
    
    
    public void searchData(Connection conn) 
    {
      java.sql.PreparedStatement prep_statement = null;

      String sql = "Select country, region, city, longitude, latitude From lab05.geocity Where city=?;";
      Scanner input = new Scanner(System.in);
      System.out.println("Enter a city: ");
      String city = input.nextLine();		
      System.out.println("Your entered city is: "+city);
      
	  try {
		prep_statement = conn.prepareStatement(sql);
		prep_statement.setString(1, city);
		
		ResultSet rs = prep_statement.executeQuery();

		//Extract data from result set
		            while (rs.next()) {
		                //Retrieve by column name & Display values
		                System.out.print("Country: " + rs.getString("country"));
		                System.out.print(", Region: " + rs.getString("region"));
		                System.out.print(", City: " + rs.getString("city"));
		                System.out.println(", Longitude: " + rs.getString("longitude"));
		                System.out.println(", Latitude: " + rs.getString("latitude"));
		            }

	} 
	  
		  
	  catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
    }
    
    public void greatCircle(Connection conn) 
    {
    	
    	Scanner in_1 = new Scanner(System.in);
        System.out.println("Enter Longitude: ");
        Double lon = in_1.nextDouble();	
        
    	Scanner in_2 = new Scanner(System.in);
        System.out.println("Enter Latitude: ");
        Double lat = in_2.nextDouble();	
        
        System.out.println("Your entered Longitude is:"+lon+" and Latitude is:"+lat);
               
        String sql = "SELECT locId, country, region,city,latitude, longitude,111.045* DEGREES(ACOS(COS(RADIANS(latpoint)) * COS(RADIANS(latitude)) * COS(RADIANS(longpoint) - RADIANS(longitude)) + SIN(RADIANS(latpoint))* SIN(RADIANS(latitude)))) AS distance_in_km FROM lab05.geocity JOIN ( SELECT  "+lat+"  AS latpoint,  "+lon+" AS longpoint) AS p ON 1=1 ORDER BY distance_in_km LIMIT 20";
        
        try {
        	
        
        
        Statement stmt = (Statement) conn.createStatement();
        
        ResultSet rs = stmt.executeQuery(sql);
        while(rs.next()){
           String country  = rs.getString("country");
           String region = rs.getString("region");
           String city = rs.getString("city");
           double latitude = rs.getDouble("latitude");
           double longitude = rs.getDouble("longitude");
           double distance = rs.getDouble("distance_in_km");
           System.out.println(country+"  "+region+"  "+city+"  "+latitude+"  "+longitude+" "+distance);
        }
        
               }  
        
  	  catch (SQLException e) {
  		// TODO Auto-generated catch block
  		e.printStackTrace();
  	}
        

    	
    }
    

};