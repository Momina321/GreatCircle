import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Test;


public class GeoCityTest {

    @Test(timeout=100000)
	public void test() {
		fail("Not yet implemented");
        DBase db = new DBase();
        Connection conn = db.connect("jdbc:mysql://localhost:3306/lab05","root","");
        db.importData(conn);
    }
    @Test(timeout=100000)
	public void test_2() {
		fail("Not yet implemented");
        DBase db = new DBase();
        Connection conn = db.connect("jdbc:mysql://localhost:3306/lab05","root","");
        db.searchData(conn);
    }
    @Test(timeout=100000)
	public void test_3() {
		fail("Not yet implemented");
        DBase db = new DBase();
        Connection conn = db.connect("jdbc:mysql://localhost:3306/lab05","root","");
        db.greatCircle(conn);
    }

	}

